from groq import Groq
from json import load, dump
import datetime
from dotenv import dotenv_values

# Load environment variables safely
env_vars = dotenv_values(".env")

# Ensure all environment variables are set
Username = env_vars.get("Username") or "User"  # Default: "User" if None
Assistantname = env_vars.get("Assistantname") or "Assistant"  # Default: "Assistant"
GroqAPIKey = env_vars.get("GroqAPIKey")

# Ensure API key is provided
if not GroqAPIKey:
    raise ValueError("❌ Groq API Key is missing. Please check your .env file.")

# Initialize Groq client
client = Groq(api_key=GroqAPIKey)

messages = []

# Define the system message safely
System = (
    f"***Hello, I am {Username}, I am your owner and creator.*** "
    f"***I build You from scratch your'e my perosnal AI assistant and i am a BTech 3rd year student of SRIT university and i am mostly intereseted in AI,ML,DL and i am really serious and passoniate about my carrier and future I am responsible mature Computer Science engineer,***"
    f"***My Father's Name is Mukesh Vishwakarma, and My Mother's Name is Kirti Vishwakarma.***"
    f"***My siblings are my brother Abhikansh Vishwakarma and my sister Aanya Vishwakarma.***\n"
    f"***You are a very accurate and advanced AI chatbot named {Assistantname},*** "
    f"which also has real-time up-to-date information from the internet.***\n"
    f"***Do not tell time until I ask, do not talk too much, just answer the question.***\n"
    f"***Reply only in English, even if the question is in Hindi, reply in English.***\n"
    f"***Do not provide notes in the output, just answer the question, and never mention your training data.***"
)

systemChatBot = [{"role": "system", "content": System}]

# Load chat history safely
try:
    with open("Data/ChatLog.json", "r") as f:
        messages = load(f)
except (FileNotFoundError, ValueError):  # Handle missing or corrupted JSON file
    with open("Data/ChatLog.json", "w") as f:
        dump([], f)
    messages = []

# Function to provide real-time information
def RealtimeInformation():
    try:
        current_date_time = datetime.datetime.now()
        return (
            "Please use the real-time information if needed:\n"
            f"Day: {current_date_time.strftime('%A')}\n"
            f"Date: {current_date_time.strftime('%d')}\n"
            f"Month: {current_date_time.strftime('%B')}\n"
            f"Year: {current_date_time.strftime('%Y')}\n"
            f"{current_date_time.strftime('%H')} Hour "
            f"{current_date_time.strftime('%M')} Minute "
            f"{current_date_time.strftime('%S')} Seconds."
        )
    except Exception as e:
        print(f"❌ Error in RealtimeInformation: {e}")
        return "Real-time information is currently unavailable."

# Function to clean and format the chatbot's response
def AnswerModifier(Answer):
    if not Answer:  # Prevent NoneType errors
        return "⚠️ No response received from AI."
    lines = Answer.split("\n")
    non_empty_lines = [line.strip() for line in lines if line.strip()]
    return "\n".join(non_empty_lines)

# Chatbot function
def ChatBot(Query):
    try:
        if not Query.strip():  # Prevent empty inputs
            return "⚠️ Please enter a valid question."

        # Reload chat history
        with open("Data/ChatLog.json", "r") as f:
            messages = load(f)

        messages.append({"role": "user", "content": Query})

        # API call to Groq
        completion = client.chat.completions.create(
            model="deepseek-r1-distill-llama-70b",
            messages=systemChatBot + [{"role": "system", "content": RealtimeInformation()}] + messages,
            max_tokens=131072,
            temperature=0.6,
            top_p=0.95,
            stream=True,
            stop=None
        )

        Answer = ""
        for chunk in completion:
            if chunk.choices and chunk.choices[0].delta and chunk.choices[0].delta.content:
                Answer += chunk.choices[0].delta.content  # Append chunk data to Answer

        Answer = (Answer or "").replace("</s>", "").strip()  # Handle None values safely
        messages.append({"role": "assistant", "content": Answer})

        # Save updated chat history
        with open("Data/ChatLog.json", "w") as f:
            dump(messages, f, indent=4)

        return AnswerModifier(Answer)

    except Exception as e:
        print(f"❌ ChatBot Error: {e}")
        return "⚠️ An error occurred. Please try again."

# Main execution
if __name__ == "__main__":
    while True:
        try:
            user_input = input("Enter Your Question: ").strip()
            if user_input.lower() in ["exit", "quit"]:
                print("👋 Exiting chatbot.")
                break
            print(ChatBot(user_input))
        except KeyboardInterrupt:
            print("\n👋 Exiting chatbot.")
            break










