from googlesearch import search
from groq import Groq
from json import load, dump
import datetime
from dotenv import dotenv_values

# Load environment variables
env_vars = dotenv_values(".env")
Username = env_vars.get("Username")
Assistantname = env_vars.get("Assistantname")
GroqAPIKey = env_vars.get("GroqAPIKey")

# Initialize Groq client
client = Groq(api_key=GroqAPIKey)

# System message
System = f"""***Hello, I am {Username},I am Your Creator and Owner. 
I built You from scratch. You're my personal AI assistant. 
I am a BTech 3rd year student of SRIT university, and I am mostly interested in AI, ML, and DL.
I am really serious and passionate about my career and future. I am a responsible and mature Computer Science engineer.***
***You are a very accurate and advanced AI chatbot named {Assistantname}, which has real-time up-to-date information from the internet.***
***Provide answers in a professional way, using full stops, commas, question marks, and proper grammar.***"""

# Load chat log or create an empty file if it doesn't exist
try:
    with open(r"Data\ChatLog.json") as f:
        messages = load(f)
except:
    with open(r"Data\ChatLog.json", "w") as f:
        dump([], f)

# Function to fetch Google search results
def GoogleSearch(Query):
    results = list(search(Query, advanced=True, num_results=5))
    if not results:
        return "No search results found."

    Answer = f"The Search results for '{Query}' are:\n[start]\n"
    for i in results:
        Answer += f"Title: {i.title}\n Description: {i.description}\n\n"
    Answer += "[end]"
    return Answer

# Function to remove empty lines from answers
def AnswerModifier(Answer):
    lines = Answer.split("\n")
    non_empty_lines = [line for line in lines if line.strip()]
    return "\n".join(non_empty_lines)

# Default system messages
SystemChatBot = [
    {"role": "system", "content": "System"},
    {"role": "user", "content": "Hi"},
    {"role": "assistant", "content": "Hello Abhinav Sir!!, How can I help you today?"}
]

# Function to provide real-time information
def Information():
    current_date_time = datetime.datetime.now()
    day = current_date_time.strftime("%A")
    date = current_date_time.strftime("%d")
    month = current_date_time.strftime("%B")
    year = current_date_time.strftime("%Y")
    hour = current_date_time.strftime("%H")
    minute = current_date_time.strftime("%M")
    second = current_date_time.strftime("%S")

    return f"""Use This Real-Time Information if needed:
    Day: {day}
    Date: {date}
    Month: {month}
    Year: {year}
    Time: {hour} hours, {minute} minutes, {second} seconds.
    """

# Function to generate AI response using real-time search
def RealtimeSearchEngine(prompt):
    global SystemChatBot, messages

    # Load chat history
    with open(r"Data\ChatLog.json", "r") as f:
        messages = load(f)

    # Add user message
    messages.append({"role": "user", "content": f"{prompt}"})

    # Add Google search results
    search_results = GoogleSearch(prompt)
    if search_results:
        SystemChatBot.append({"role": "system", "content": search_results})

    # Ensure system messages have content
    system_info = Information()
    if not system_info:
        system_info = "Real-time information not available."

    messages = SystemChatBot + [{"role": "system", "content": system_info}] + messages

    # Remove empty messages to prevent API errors
    messages = [msg for msg in messages if msg.get("content")]

    # Generate AI response
    completion = client.chat.completions.create(
        model="llama3-70b-8192",
        messages=messages,
        temperature=0.7,
        max_tokens=2048,
        top_p=1,
        stream=True,
        stop=None
    )

    # Extract response text
    Answer = ""
    for chunk in completion:
        if chunk.choices and chunk.choices[0].delta and chunk.choices[0].delta.content:
            Answer += chunk.choices[0].delta.content

    # Clean up response
    Answer = Answer.strip().replace("</s>", "")

    # Save to chat log
    messages.append({"role": "assistant", "content": Answer})
    with open(r"Data\ChatLog.json", "w") as f:
        dump(messages, f, indent=4)

    return AnswerModifier(Answer)

# Run chatbot loop
if __name__ == "__main__":
    while True:
        prompt = input("Enter Your Query :- ")
        print(RealtimeSearchEngine(prompt))
